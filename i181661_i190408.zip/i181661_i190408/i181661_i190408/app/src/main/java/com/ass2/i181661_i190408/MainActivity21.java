package com.ass2.i181661_i190408;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity21 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen21);
    }
}