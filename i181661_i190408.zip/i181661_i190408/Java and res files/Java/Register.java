package com.ahmadarif.musify;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {
    EditText username, email, password;
    Button signup_btn;
    TextView signin_btn;
    FirebaseAuth fAuth;

    protected void OnCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen2);

        username = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        fAuth = FirebaseAuth.getInstance();

        if(fAuth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(), MainActivity5.class));
            finish();
        }

        signup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n = username.getText().toString().trim();
                String e = email.getText().toString().trim();
                String p = password.getText().toString().trim();

                if(TextUtils.isEmpty((CharSequence) username)) {
                    username.setError("Username is required.");
                    return;
                }

                if(TextUtils.isEmpty((CharSequence) email)) {
                    email.setError("Email is required.");
                    return;
                }

                if(TextUtils.isEmpty((CharSequence) password)) {
                    password.setError("Password is required.");
                    return;
                }

                Task<AuthResult> authResultTask = fAuth.createUserWithEmailAndPassword(username, email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(Register.this, "User created", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity2.class));
                        }
                        else {
                            Toast.makeText(Register.this, "Error" + task.getException().getMessage(), Toast.LENGTH_SHORT);

                        }
                    }
                });
            }
        });
    }

}
