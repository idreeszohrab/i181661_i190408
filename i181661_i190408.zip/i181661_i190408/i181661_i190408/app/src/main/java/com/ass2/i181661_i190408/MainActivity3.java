package com.ass2.i181661_i190408;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity3 extends AppCompatActivity {

    EditText username, password
    Button signup_btn;
    Button signin_btn;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen3);


        username = findViewById(R.id.name);
        password = findViewById(R.id.password);
        signup_btn = findViewById(R.id.signup_btn);
        signin_btn = findViewById(R.id.signin_btn);
        fAuth = FirebaseAuth.getInstance();

        signup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent( MainActivity3.this, com.ahmadarif.musify.MainActivity2.class));
            }
        });
        signin_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                @Override
                public void onClick(View view){
                    String n = username.getText().toString().trim();
                    String p = password.getText().toString().trim();

                    if (TextUtils.isEmpty((CharSequence) username)) {
                        username.setError("Username is required.");
                        return;
                    }

                    if (TextUtils.isEmpty((CharSequence) password)) {
                        password.setError("Password is required.");
                        return;
                    }

                }
                fAuth.signInWithEmailAndPassword(username, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(Login.this, "Logged in", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent( MainActivity3.this, MainActivity5.class));
                        }
                        else {
                            Toast.makeText(Login.this, "Error" + task.getException().getMessage(), Toast.LENGTH_SHORT);

                        }
                    }
                });
            }
        });



    }
}